# Client Communication Templates - SoloForge

## 1. Cold Pitch Email (EN)
Subject: Quick question about [their company]

Hi [Name],

I noticed your team is doing great work on [specific project]. I specialize in [your skill] and I think I could help you with [specific problem].

Would you be open to a 15-minute chat this week?

Best,
[Your Name]

---

## 2. Cold Pitch (??)
??: ??????[????]

[??]???

??????[??]?????????[????]?????????????[????]?

?????15????

??
[????]

---

## 3. Follow-up After No Response (EN)
Subject: Re: Quick question about [their company]

Hi [Name],

Just following up on my last email. I know you are busy - let me know if this is not a priority right now.

[Your Name]

---

## 4. ????????
??: ??: ??[??]

[??]???

???????????????????????????

[????]

---

## 5. Project Proposal Summary (EN)
Subject: Proposal for [project name]

Hi [Name],

Here is a summary of what we discussed:

Project: [name]
Timeline: [X weeks]
Investment: $[amount]
Deliverables: [list]

Next step: sign and return the attached agreement to get started.

Best,
[Your Name]

---

## 6. Rate Increase Notice (EN)
Subject: Upcoming rate adjustment

Hi [Name],

I am writing to let you know that starting [date], my rate will be adjusted to $[new rate]/hour.

This reflects the increased value I bring to our work together. Your current project pricing remains unchanged.

Happy to discuss.

[Your Name]

---

## 7. Polite No (EN)
Subject: Re: [project inquiry]

Hi [Name],

Thank you for thinking of me. I do not think I am the right fit for this project, but I can recommend [alternative person/resource].

Wishing you the best with it.

[Your Name]

---

## 8. Asking for Testimonial (EN)
Subject: Quick favor?

Hi [Name],

I really enjoyed working with you on [project]. Would you be willing to write a short testimonial about our work together? Even 2-3 sentences would mean a lot.

Thank you!

[Your Name]
