# Solo Income Toolkit - SoloForge

## What is Inside (5 Tools)

| # | Tool | Format | Use For |
|---|------|--------|---------|
| 1 | Freelance Pricing Calculator | Excel/CSV | Calculate your minimum hourly rate and project prices |
| 2 | Side Hustle Income Tracker | Excel/CSV | Track all income streams month by month |
| 3 | Client Email Templates | Markdown/Text | 8 ready-to-use email scripts (English + Chinese) |
| 4 | Project Deadline Tracker | Excel/CSV | Manage multiple projects, budgets, deadlines |
| 5 | Monthly Profit Dashboard | Excel/CSV | Full-year revenue vs expenses dashboard |

## How to Use

1. Open any CSV file in Excel, Google Sheets, or WPS Office
2. Fill in the colored cells with your numbers
3. All formulas auto-calculate

## Support

For questions: [your email]

---

SoloForge - Tools for Independent Makers
